<?php
    require_once('phpmailer/class.phpmailer.php');
    $mail = new PHPMailer();

    $name   = strip_tags($_POST['name']);
    $phone  = strip_tags($_POST['phone']);		
    $time   = strip_tags($_POST['time']);

    $subject    = "Garage Door Asap Service / Orlando";

    $recipient  = 'garagedoorasapservice@gmail.com';
    $cc         = 'bolanaguib@gmail.com';

    $email_content = "<h1><b>Callback Form Submission</b></h1><br/>";
    $email_content .= "Name: $name <br/>";
    $email_content .= "Phone: $phone <br/>";
    $email_content .= "Preferred Callback Time: $time <br/>";
    $email_content .= "sent from : Orlando  <br/>";

    $mail->SetFrom($email, $name);

    $mail->AddAddress($recipient, "Garage Door ASAP Service ");
    $mail->AddCC($cc, "Garage Door ASAP Service ");

    $mail->Subject = $subject;
    $mail->MsgHTML($email_content);

    $sendnow = $mail->Send();

    if ($sendnow) {

        header('Location: ../thankyou.html');
        
        die();
    }  else {
        
        echo '<script language="javascript">alert("Failed, please submit form again ")</script>';
        echo '<script language="javascript">history.go(-1);</script>';
     
    }


?>