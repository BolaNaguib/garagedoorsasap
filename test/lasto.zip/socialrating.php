 <section class="page-section transparent gay">
       	<div class="container">
       		<div class="row">
       			<h1> WE PROMISE, YOU'LL LOVE US TOO </h1>
       			<hr>
       			<br>
       			<div class="col-md-3">
       			       			

       			<div class="col-md-4">       				       				
       			<a target="_blank" href="https://www.yelp.com/biz/garage-door-asap-service-clermont">
       			<img src="img/social/yy.png">
  				</a>

</div>
      				       				<div class="col-md-8">
      				       					<h3> YELP </h3>
	<img class="staros" src="img/social/star.png">
       				<img class="staroh" src="img/social/staro.png">      				       				</div>

       			</div>
      			
       			<div class="col-md-3">
     				       				
      				       				<div class="col-md-4">       				       				
      				       				<a target="_blank" href="https://www.google.com/maps/place/Garage+Door+ASAP+Service/@28.505861,-81.7689547,17z/data=!4m7!3m6!1s0x88e7894ff1fd8cc3:0x4bd696395a30e80b!8m2!3d28.505861!4d-81.766766!9m1!1b1">
											<img src="img/social/gg.png"></a>
</div>
      				       				<div class="col-md-8">
      				       					<h3> GOOGLE 

 </h3>
	<img class="staros" src="img/social/star.png">
       				<img class="staroh" src="img/social/staro.png">      				       				</div>

       			</div>
       			<div class="col-md-3">
       				       				<div class="col-md-4">       				       				
       				       				      			<a target="_blank" href="https://www.facebook.com/Garagedoorasapservice/">

       				       				<img src="img/social/ff.png">
											</a>
</div>
      				       				<div class="col-md-8">
      				       					<h3> FACEBOOK </h3>
       				<img class="staros" src="img/social/star475.png">
       				<img class="staroh" src="img/social/staro.png">
      				       				</div>
       			</div>
       				<div class="col-md-3">
       				       				<div class="col-md-4">       				       				
       				       				      			<a target="_blank" href="https://member.angieslist.com/member/store/24091134?ref=search&categoryId=68">

       				       				<img src="img/social/aa.png">
											</a>
</div>
      				       				<div class="col-md-8">
      				       					<h3> ANGIES </h3>
       				<img class="staros" src="img/social/star55.png">
       				<img class="staroh" src="img/social/star5.png">
      				       				</div>
       			</div>
       			
       		</div>
       	</div>
       	
       </section>