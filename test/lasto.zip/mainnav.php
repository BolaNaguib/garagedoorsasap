  <!-- Sticky Navbar -->
      <header id="sticker" class="sticky-navigation dark-header">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <!-- Top Contact -->
                        <div class="top-contact link-hover-black">
                        <a href="tel:+18779197828">
                        <i class="fa fa-phone"></i>(877) 919-7828</a> 
                        <a href="mailto:garagedoorasapservice@gmail.com">
                        <i class="fa fa-envelope"></i>garagedoorasapservice@gmail.com</a></div>
                        <!-- Top Social Icon -->
                        <div class="top-social-icon icons-hover-black">
                        <a href="https://www.facebook.com/Garagedoorasapservice/" target="_blank">
                            <i class="fab fa-facebook-f"></i>
                        </a>  
                        <a href="https://www.youtube.com/channel/UCruZpdtFdDZq0obavLzPdyA" target="_blank">
                            <i class="fab fa-youtube"></i>
                        </a> 
                        <a href="https://goo.gl/maps/N6nmFKD27U82" target="_blank">
                            <i class="fas fa-map-marker-alt"></i>
                        </a> 
                           <a href="#usa" >
<img src="img/social/usa.png">                        </a> 
                    </div>
                </div>
            </div>
        </div>
            <!-- Sticky Menu -->
            <div class="sticky-menu relative">
                <!-- navbar -->
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="navbar-header">
                                <!-- Button For Responsive toggle -->
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span> 
                                <span class="icon-bar"></span> 
                                <span class="icon-bar"></span> 
                                <span class="icon-bar"></span></button> 
                                <!-- Logo -->
                                 
                                <a class="navbar-brand" href="index.php">
                                    <img class="site_logo" alt="Site Logo" src="img/logo.png" />
                                </a></div>
                                <!-- Navbar Collapse -->
                                <div class="navbar-collapse collapse">
                                    <!-- nav -->
                                    <ul class="nav navbar-nav">
                                        <!-- Home  Mega Menu -->
                                        <li>
                                            <a href="index.php">Home</a>
                                        </li>
										<li>
                                            <a href="about.php">About</a>
                                        </li>
										<li>
                                            <a class="active" href="">Services</a>
                                             <ul class="dropdown-menu">
                                               <li>
<a href="General-Maintnance.php">Garage Door General Maintenance</a></li><li>      	          	
<a href="Garage-Door-Spring-Replacment.php">Garage Door Spring Replacement</a></li><li>
<a href="Garage-Door-Opener-Repair.php">Garage Door Opener Repair</a></li><li>
<a href="Garage-door-opener-replacment.php">Garage Door Opener Replacement</a></li><li>
<a href="Garage-Door-Roller-Replacment.php">Garage Door Roller Replacement</a></li><li>
<a href="Garage-Door-Shifted-Door-Repair.php">Shifted Garage Door Repair</a></li>
                                            </ul>
                                        </li>
									
										<li>
                                            <a href="testimonials.php">Reviews</a>
                                        </li>
                                        <!-- Contact Block -->
                                        <li>
                                            <a href="contact.php">Contact</a>
                                        </li>
                                        <!-- Ends Contact Block -->
										<!-- Features Menu -->
                                        <li class="mega-menu">
                                            <a href="#">Locations</a>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <!-- Home Mage Menu grids Begins -->
                                                    <div class="row">
                                                        <!-- Page Block -->
                                                        <div class="col-sm-3">
                                                            <!-- Title -->
                                                            <h6 class="title">Cities we serve</h6>
                                                            <!-- Links -->
                                                            <div class="page-links">
                                                               
<div><a href="garage_door_repair_Orlando_Fl.php"> Orlando </a></div>
<div><a href="garage_door_repair_Kissimmee_Fl.php"> Kissimmee </a></div>
<div><a href="garage_door_repair_The_Villages_Fl.php"> The Villages </a></div>
<div><a href="Clermont.php"> Clermont </a></div>
<div><a href="garage_door_repair_Apopka_Fl.php"> Apopka </a></div>
<div><a href="garage_door_repair_Winter_Garden_Fl.php"> Winter Garden </a></div>
<div><a href="garage_door_repair_Winter_Park_Fl.php"> Winter Park </a></div>
<div><a href="garage_door_repair_Sanford_Fl.php"> Sanford </a></div>
<div><a href="garage_door_repair_Casselberry_Fl.php"> Casselberry </a></div>
<div><a href="garage_door_repair_Oviedo_Fl.php"> Oviedo </a></div>
<div><a href="garage_door_repair_Lake_Mary_Fl.php"> Lake Mary </a></div>
<div><a href="garage_door_repair_Altamonte_Springs_Fl.php"> Altamonte Springs </a></div>
<div><a href="garage_door_repair_Longwood_Fl.php"> Longwood </a></div>
<div><a href="garage_door_repair_Windermere_Fl.php"> Windermere </a></div>
<div><a href="garage_door_repair_SaintCloud_Fl.php"> SaintCloud </a></div>


                                                            </div>
                                                        </div>
                                                        <!-- Page Block -->
                                                        <div class="col-sm-3">
                                                            <!-- Title -->
                                                            <h6 class="title"></h6>
                                                            <!-- Links -->
                                                            <div class="page-links">
                                                               


<div><a href="garage_door_repair_Leesburg_Fl.php"> Leesburg </a></div>
<div><a href="garage_door_repair_Ocoee_Fl.php"> Ocoee </a></div>
<div><a href="garage_door_repair_Pine_Hills_Fl.php"> Pine Hills </a></div>
<div><a href="garage_door_repair_Groveland_Fl.php"> Groveland </a></div>
<div><a href="garage_door_repair_Eustis_Fl.php"> Eustis </a></div>
<div><a href="garage_door_repair_Maitland_Fl.php"> Maitland </a></div>
<div><a href="garage_door_repair_Wildwood_Fl.php"> Wildwood </a></div>
<div><a href="garage_door_repair_Minneola_Fl.php"> Minneola </a></div>
<div><a href="garage_door_repair_Mount_Dora_Fl.php"> Mount Dora </a></div>
<div><a href="garage_door_repair_Tavares_Fl.php"> Tavares </a></div>
<div><a href="garage_door_repair_Lockhart_Fl.php"> Lockhart </a></div>
<div><a href="garage_door_repair_Saint_Cloud_Fl.php"> Saint Cloud </a></div>
<div><a href="garage_door_repair_Winter_Springs_Fl.php"> Winter Springs </a></div>
<div><a href="garage_door_repair_Coleman_Fl.php"> Coleman </a></div>
<div><a href="garage_door_repair_Umatilla_Fl.php"> Umatilla </a></div>


                                                            </div>
                                                        </div>
                                                        <!-- Button Block-->
                                                      <div class="col-sm-3">
                                                            <!-- Title -->
                                                            <h6 class="title"></h6>
                                                            <!-- Links -->
                                                            <div class="page-links">
                                       

<div><a href="garage_door_repair_Fruitland_Park_Fl.php"> Fruitland Park </a></div>
<div><a href="garage_door_repair_Lady_Lake_Fl.php"> Lady Lake </a></div>
<div><a href="garage_door_repair_Bushnell_Fl.php"> Bushnell </a></div>
<div><a href="garage_door_repair_Mascotte_Fl.php"> Mascotte </a></div>
<div><a href="garage_door_repair_Grand_Island_Fl.php"> Grand Island </a></div>
<div><a href="garage_door_repair_Webster_Fl.php"> Webster </a></div>
<div><a href="garage_door_repair_Montverde_Fl.php"> Montverde </a></div>
<div><a href="garage_door_repair_Astatula_Fl.php"> Astatula </a></div>
<div><a href="garage_door_repair_Fairview_Shores_Fl.php"> Fairview Shores </a></div>
<div><a href="garage_door_repair_CenterHill_Fl.php"> CenterHill </a></div>
<div><a href="garage_door_repair_Oakland_Fl.php"> Oakland </a></div>
<div><a href="garage_door_repair_Gotha_Fl.php"> Gotha </a></div>

                                                            </div>
                                                        </div>
                                                        <!-- Button Block -->
														    <div class="col-sm-3">
                                                            <!-- Title -->
                                                            <h6 class="title"> Counties we serve</h6>
                                                            <!-- Links -->
                                                            <div class="page-links">
                                       


<div><a href="garage_door_repair_Orange_County_Fl.php"> Orange County, Florida </a></div>
<div><a href="garage_door_repair_Seminole_County_Fl.php"> Seminole County, Florida </a></div>
<div><a href="garage_door_repair_Osceola_County_Fl.php"> Osceola County, Florida </a></div>
<div><a href="garage_door_repair_Lake_County_Fl.php"> Lake County, Florida </a></div>
<div><a href="garage_door_repair_Volusia_County_Fl.php"> Volusia County, Florida </a></div>
<div><a href="garage_door_repair_Pinellas_County_Fl.php"> Pinellas County, Florida </a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Ends Home Mage Menu Block -->
                                                </li>
                                            </ul>
                                        </li>
                                        <!-- Ends Features Menu -->
                                    </ul>
                                    <!-- Right nav -->
                                </div>
                                <!-- /.navbar-collapse -->
                            </div>
                            <!-- /.col-md-12 -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container -->
                </div>
                <!-- navbar -->
            </div>
            <!-- Sticky Menu -->
        </header>