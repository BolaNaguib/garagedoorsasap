 </p></div>
                        <div class="col-xs-12 col-sm-6 col-md-3 widget bottom-xs-pad-20">
                            <div class="widget-title">
                                <!-- Title -->
                                <h3 class="title">Services</h3>
                            </div>
                            <nav>
                                <ul>
                                    <!-- List Items -->
                                      <li>
<a href="General-Maintnance.php">Garage Door General Maintenance</a></li><li>      	          	
<a href="Garage-Door-Spring-Replacment.php">Garage Door Spring Replacement</a></li><li>
<a href="Garage-Door-Opener-Repair.php">Garage Door Opener Repair</a></li><li>
<a href="Garage-door-opener-replacment.php">Garage Door Opener Replacement</a></li><li>
<a href="Garage-Door-Roller-Replacment.php">Garage Door Roller Replacement</a></li><li>
<a href="Garage-Door-Shifted-Door-Repair.php">Shifted Garage Door Repair</a></li>
                                </ul>
                            </nav>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-3 widget">
                            <div class="widget-title">
                                <!-- Title -->
                                <h3 class="title">Business Hours</h3>
                            </div>
                            <nav>
                                <ul>
                                    <!-- List Items -->
                                    <li>
                                        <a href="#">24 hours a day.</a>
                                    </li>
                                    <li>
                                        <a href="#">7 days a week.</a>
                                    </li>
                                </ul>
                                <!-- Count -->
                                <div class="footer-count">
                                    <p class="count-number" data-count="3550">total projects : 
                                    <span class="counter"></span></p>
                                </div>
                                <div class="footer-count">
                                    <p class="count-number" data-count="2550">happy clients : 
                                    <span class="counter"></span></p>
                                </div>
                            </nav>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-3 widget newsletter bottom-xs-pad-20">
                            <div class="widget-title">
                                <!-- Title -->
                                <h3 class="title">Follow us</h3>
                            </div>
                         
                            <!-- Social Links -->
                            <div class="social-icon gray-bg icons-circle i-3x">
                            <a href="https://www.facebook.com/Garagedoorasapservice/" target="_blank">
								<i class="fab fa-facebook-f"></i>
							</a>  
							<a href="https://www.youtube.com/channel/UCruZpdtFdDZq0obavLzPdyA" target="_blank">
								<i class="fab fa-youtube"></i>
							</a> 
								</div>
					