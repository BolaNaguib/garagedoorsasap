    <?php include('socialrating.php'); ?>

           <footer id="footer">
            <div class="footer-widget">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-md-3 widget bottom-xs-pad-20">
                        <div class="widget-title">
                            <!-- Title -->
                            <h3 class="title">Address</h3>
                        </div>
                        <!-- Address -->
                        <p>