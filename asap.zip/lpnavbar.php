 <meta name="author" content="Convert X Media" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <!-- Favicon -->
        <link rel="shortcut icon" href="img/favicon.ico" />
        <!-- Font -->
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Arimo:300,400,500,700,400italic,700italic' />
        <link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css' />
        <!-- Font Awesome Icons -->
		<link href='css/font-awesome.min.css' rel='stylesheet' type='text/css' />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous" />
        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet" />
        <link href="css/hover-dropdown-menu.css" rel="stylesheet" />
        <!-- Icomoon Icons -->
        <link href="css/icons.css" rel="stylesheet" />
        <!-- Revolution Slider -->
        <link href="css/revolution-slider.css" rel="stylesheet" />
        <link href="rs-plugin/css/settings.css" rel="stylesheet" />
        <!-- Animations -->
        <link href="css/animate.min.css" rel="stylesheet" />
        <!-- Owl Carousel Slider -->
        <link href="css/owl/owl.carousel.css" rel="stylesheet" />
        <link href="css/owl/owl.theme.css" rel="stylesheet" />
        <link href="css/owl/owl.transitions.css" rel="stylesheet" />
        <!-- PrettyPhoto Popup -->
        <link href="css/prettyPhoto.css" rel="stylesheet" />
        <!-- Custom Style -->
        <link href="css/style.css" rel="stylesheet" />
        <link href="css/responsive.css" rel="stylesheet" />
        <!-- Color Scheme -->
        <link href="css/color.css" rel="stylesheet" />
    </head>
    <body>
    <div id="page" class="page-wrap lpo">
        <!-- Page Loader -->
        <div id="pageloader">
            <div class="loader-item fa fa-spin text-color"></div>
        </div>
        <!-- Top Bar -->
        <div id="top-bar" class="top-bar-section top-bar-bg-dark ">
          
        <!-- Top Bar -->
        <!-- Sticky Navbar -->
        <header id="sticker" class="sticky-navigation dark-header">
            <!-- Sticky Menu -->
                <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <!-- Top Contact -->
                        <div class="top-contact link-hover-black">
                        <a href="tel:+18779197828">
                        <i class="fa fa-phone"></i>(877) 919-7828</a> 
                        <a href="mailto:garagedoorasapservice@gmail.com">
                        <i class="fa fa-envelope"></i>garagedoorasapservice@gmail.com</a></div>
                        <!-- Top Social Icon -->
                        <div class="top-social-icon icons-hover-black">
                        <a href="https://www.facebook.com/Garagedoorasapservice/" target="_blank">
                            <i class="fab fa-facebook-f"></i>
                        </a>  
                        <a href="https://www.youtube.com/channel/UCruZpdtFdDZq0obavLzPdyA" target="_blank">
                            <i class="fab fa-youtube"></i>
                        </a> 
                        <a href="https://goo.gl/maps/N6nmFKD27U82" target="_blank">
                            <i class="fas fa-map-marker-alt"></i>
                        </a> 
                    </div>
                </div>
            </div>
        </div>
            <div id="" class="sticky-menu relative">
                <!-- navbar -->
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="navbar-header">
                                <!-- Button For Responsive toggle -->
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span> 
                                <span class="icon-bar"></span> 
                                <span class="icon-bar"></span> 
                                <span class="icon-bar"></span></button> 
                                <!-- Logo -->
                                 
                                <a class="navbar-brand" href="index.html">
                                    <img class="site_logo" alt="Site Logo" src="img/logo.png" />
                                </a></div>
                                <!-- Navbar Collapse -->
                                <div class="navbar-collapse collapse">
                                    <!-- nav -->
                            
                                    <ul id="sidebaro" class="nav navbar-nav">
                                        <!-- Home  Mega Menu -->
                                        <li>
                                            <a href="index.php">Home</a>
                                        </li>
										<li>
                                            <a href="about.php">About</a>
                                        </li>
										<li>
                                            <a class="active" href="">Services</a>
                                             <ul class="dropdown-menu">
                                              <li>
                                               <a href="General-Maintnance.php">General Maintenance</a></li><li>      	          	
<a href="Garage-Door-Spring-Replacment.php">Spring Replacement</a></li><li>
<a href="Garage-Door-Opener-Repair.php">Opener Repair</a></li><li>
<a href="Garage-door-opener-replacment.php">Opener Replacement</a></li><li>
<a href="Garage-Door-Roller-Replacment.php">Roller Replacement</a></li><li>
<a href="Garage-Door-Shifted-Door-Repair.php">Shifted Door Repair</a></li>
                                            </ul>
                                        </li>
									
										<li>
                                            <a href="testimonials.php">Testimonials</a>
                                        </li>
                                        <!-- Contact Block -->
                                        <li>
                                            <a href="contact.php">Contact</a>
                                        </li>
                                        <!-- Ends Contact Block -->
										<!-- Features Menu -->
                                        <li class="mega-menu">
                                            <a href="#">Locations</a>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <!-- Home Mage Menu grids Begins -->
                                                    <div class="row">
                                                        <!-- Page Block -->
                                                        <div class="col-sm-3">
                                                            <!-- Title -->
                                                            <h6 class="title">Cities we serve</h6>
                                                            <!-- Links -->
                                                            <div class="page-links">
                                                               
<div><a href="garage_door_repair_Orlando_Fl.php"> Orlando </a></div>
<div><a href="garage_door_repair_Kissimmee_Fl.php"> Kissimmee </a></div>
<div><a href="garage_door_repair_The_Villages_Fl.php"> The Villages </a></div>
<div><a href="Clermont.php"> Clermont </a></div>
<div><a href="garage_door_repair_Apopka_Fl.php"> Apopka </a></div>
<div><a href="garage_door_repair_Winter_Garden_Fl.php"> Winter Garden </a></div>
<div><a href="garage_door_repair_Winter_Park_Fl.php"> Winter Park </a></div>
<div><a href="garage_door_repair_Sanford_Fl.php"> Sanford </a></div>
<div><a href="garage_door_repair_Casselberry_Fl.php"> Casselberry </a></div>
<div><a href="garage_door_repair_Oviedo_Fl.php"> Oviedo </a></div>
<div><a href="garage_door_repair_Lake_Mary_Fl.php"> Lake Mary </a></div>
<div><a href="garage_door_repair_Altamonte_Springs_Fl.php"> Altamonte Springs </a></div>
<div><a href="garage_door_repair_Longwood_Fl.php"> Longwood </a></div>
<div><a href="garage_door_repair_Windermere_Fl.php"> Windermere </a></div>
<div><a href="garage_door_repair_SaintCloud_Fl.php"> SaintCloud </a></div>


                                                            </div>
                                                        </div>
                                                        <!-- Page Block -->
                                                        <div class="col-sm-3">
                                                            <!-- Title -->
                                                            <h6 class="title"></h6>
                                                            <!-- Links -->
                                                            <div class="page-links">
                                                               


<div><a href="garage_door_repair_Leesburg_Fl.php"> Leesburg </a></div>
<div><a href="garage_door_repair_Ocoee_Fl.php"> Ocoee </a></div>
<div><a href="garage_door_repair_Pine_Hills_Fl.php"> Pine Hills </a></div>
<div><a href="garage_door_repair_Groveland_Fl.php"> Groveland </a></div>
<div><a href="garage_door_repair_Eustis_Fl.php"> Eustis </a></div>
<div><a href="garage_door_repair_Maitland_Fl.php"> Maitland </a></div>
<div><a href="garage_door_repair_Wildwood_Fl.php"> Wildwood </a></div>
<div><a href="garage_door_repair_Minneola_Fl.php"> Minneola </a></div>
<div><a href="garage_door_repair_Mount_Dora_Fl.php"> Mount Dora </a></div>
<div><a href="garage_door_repair_Tavares_Fl.php"> Tavares </a></div>
<div><a href="garage_door_repair_Lockhart_Fl.php"> Lockhart </a></div>
<div><a href="garage_door_repair_Saint_Cloud_Fl.php"> Saint Cloud </a></div>
<div><a href="garage_door_repair_Winter_Springs_Fl.php"> Winter Springs </a></div>
<div><a href="garage_door_repair_Coleman_Fl.php"> Coleman </a></div>
<div><a href="garage_door_repair_Umatilla_Fl.php"> Umatilla </a></div>


                                                            </div>
                                                        </div>
                                                        <!-- Button Block-->
                                                      <div class="col-sm-3">
                                                            <!-- Title -->
                                                            <h6 class="title"></h6>
                                                            <!-- Links -->
                                                            <div class="page-links">
                                       

<div><a href="garage_door_repair_Fruitland_Park_Fl.php"> Fruitland Park </a></div>
<div><a href="garage_door_repair_Lady_Lake_Fl.php"> Lady Lake </a></div>
<div><a href="garage_door_repair_Bushnell_Fl.php"> Bushnell </a></div>
<div><a href="garage_door_repair_Mascotte_Fl.php"> Mascotte </a></div>
<div><a href="garage_door_repair_Grand_Island_Fl.php"> Grand Island </a></div>
<div><a href="garage_door_repair_Webster_Fl.php"> Webster </a></div>
<div><a href="garage_door_repair_Montverde_Fl.php"> Montverde </a></div>
<div><a href="garage_door_repair_Astatula_Fl.php"> Astatula </a></div>
<div><a href="garage_door_repair_Fairview_Shores_Fl.php"> Fairview Shores </a></div>
<div><a href="garage_door_repair_CenterHill_Fl.php"> CenterHill </a></div>
<div><a href="garage_door_repair_Oakland_Fl.php"> Oakland </a></div>
<div><a href="garage_door_repair_Gotha_Fl.php"> Gotha </a></div>

                                                            </div>
                                                        </div>
                                                        <!-- Button Block -->
														    <div class="col-sm-3">
                                                            <!-- Title -->
                                                            <h6 class="title"> Counties we serve</h6>
                                                            <!-- Links -->
                                                            <div class="page-links">
                                       


<div><a href="garage_door_repair_Orange_County_Fl.php"> Orange County, Florida </a></div>
<div><a href="garage_door_repair_Seminole_County_Fl.php"> Seminole County, Florida </a></div>
<div><a href="garage_door_repair_Osceola_County_Fl.php"> Osceola County, Florida </a></div>
<div><a href="garage_door_repair_Lake_County_Fl.php"> Lake County, Florida </a></div>
<div><a href="garage_door_repair_Volusia_County_Fl.php"> Volusia County, Florida </a></div>
<div><a href="garage_door_repair_Pinellas_County_Fl.php"> Pinellas County, Florida </a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Ends Home Mage Menu Block -->
                                                </li>
                                            </ul>
                                        </li>
                                        <!-- Ends Features Menu -->
                                    </ul>
                                       <ul class="nav navbar-nav">
                                       	<li>
                                       	 <button type="button" id="sidebarCollapse" class="navbar-btn">
<i class="fas fa-bars"></i>



                    </button> 
                                       	  </li>
                                       </ul>
                                    <!-- Right nav -->
                                </div>
                                    
                                <!-- /.navbar-collapse -->
                            </div>
                            <!-- /.col-md-12 -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container -->
                </div>
                <!-- navbar -->
            </div>
            <!-- Sticky Menu -->
        </header>
        
        <!-- Sticky Navbar -->