c<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Garage Door Repair - Garage Door Openers | Garage Door ASAP Service</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="keywords" content="automatic garage door, commercial garage doors, double garage door, electric garage doors, garage door installation, garage door motor, garage door opener, garage door opener installation, garage door opener repair, garage door repair, garage door replacement, garage door service, garage door spring repair, garage door springs, garage door torsion spring, overhead garage door, roll up garage doors, roller garage doors, sectional garage doors, wooden garage doors" />
        <meta name="description" content="Fast Local Central Florida Garage Door Repair company offers FL Garage Door Opener, FL Garage Door Installation & Repair in Orlando, Winter Garden, Leesburg, Apopka, Kissimmee, Clermont." />
          <?php include('header.php'); ?>
        <!-- Top Bar -->
        <div id="top-bar" class="top-bar-section top-bar-bg-dark">
       <?php include('mainnav.php');?>
        <!-- Sticky Navbar -->
        <div class="page-header page-title-left page-title-pattern">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="title">Testimonials</h1>
                        <h5>Our Customers' Feedback</h5>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- page-header -->
        <!-- testimonials -->
        <section id="testimonials" class="page-sections testimonials">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="section-titles">
                            <!-- Heading -->
                            <h2 class="title">Testimonials Grid</h2>
                        </div>
                        
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">Got a new garage door opener installed from Rafee he did a great job!!!!! His company can be proud of him. He corrected all our complains and now I'm a happy customer...Thank you ASAP thank you Rafee.

</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">William Glueck</strong> 
                                <!-- Company --> 
                                <span>Orlando, Florida</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                       
                        
                        <div class="item col-md-4 col-sm-6">
                            <div class="desc-border bottom-arrow quote">
                                <blockquote class="small-text">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste. The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                below for those intereste.</blockquote>
                                <div class="star-rating text-center">
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i> 
                                <i class="fa fa-star text-color"></i>
                                </div>
                            </div>
                            <div class="client-details text-center">
                                <div class="client-details">
                                <!-- Name -->
                                <strong class="text-color">John Doe</strong> 
                                <!-- Company --> 
                                <span>Designer, zozothemes</span></div>
                            </div>
                        </div>
                    
                    
                    </div>
                </div>
            </div>
        </section>
		
        <!-- scroll -->
        <div id="get-quote" class="bg-color black text-center">
            <div class="container">
                <div class="row get-a-quote">
                    <div class="col-md-12">Get A Free Quote / Need a Help ? 
                    <a class="black" href="#">Contact Us</a></div>
                </div>
                <div class="move-top bg-color page-scroll">
                    <a href="#page">
                        <i class="glyphicon glyphicon-arrow-up"></i>
                    </a>
                </div>
            </div>
        </div>
        <!-- request -->
         <?php include('footer.php'); ?>
       